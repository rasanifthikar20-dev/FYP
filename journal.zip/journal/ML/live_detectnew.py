
import time
import threading
import serial
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from pathlib import Path
from collections import deque
from matplotlib.animation import FuncAnimation

# ==================================================
# CONFIGURATION
# ==================================================

BASE_DIR = Path(__file__).resolve().parent
PORT = "COM3"
BAUD_RATE = 115200

CONFIDENCE_THRESHOLD = 0.80
WINDOW_SIZE = 10
REQUIRED_ACCIDENTS = 5

GRAPH_POINTS = 200
GRAPH_REFRESH_MS = 100

# ==================================================
# LOAD MODEL FILES
# ==================================================

try:
    model = joblib.load(BASE_DIR / "helmet_model.pkl")
    encoder = joblib.load(BASE_DIR / "label_encoder.pkl")
    model_features = list(
        joblib.load(BASE_DIR / "model_features.pkl")
    )
    print("ML model loaded successfully.")

except FileNotFoundError as error:
    print("Model file missing:", error)
    raise SystemExit(1)

if not hasattr(model, "predict_proba"):
    print("Error: Model must support predict_proba().")
    raise SystemExit(1)

expected_features = {
    "AX", "AY", "AZ", "GX", "GY", "GZ",
    "ACC_MAG", "GYRO_MAG"
}

if set(model_features) != expected_features:
    print("Unexpected model features:", model_features)
    print("Retrain the model with the matching training code.")
    raise SystemExit(1)

print("Encoder classes:", list(encoder.classes_))
print("Model classes:", list(model.classes_))


# ==================================================
# ROBUST CLASS-LABEL HANDLING
# ==================================================

def normalize_label(value):
    """Normalize a class label to lowercase text."""
    return str(value).strip().lower()


def get_class_name(class_id):
    """
    Convert a model class to a readable label.

    Supports:
    1. Model trained on encoded integer labels.
    2. Model trained directly on string labels.
    3. Numeric-string labels matching encoder indices.
    """
    # First try the label encoder's inverse transform.
    try:
        decoded = encoder.inverse_transform(
            np.asarray([class_id])
        )[0]
        return normalize_label(decoded)
    except (ValueError, TypeError, IndexError):
        pass

    # The model may have been trained on string labels directly.
    direct_label = normalize_label(class_id)
    if direct_label in ("accident", "normal"):
        return direct_label

    # Handle integer class IDs when compatible with the encoder.
    try:
        numeric_id = int(class_id)

        if str(class_id).strip() in (
            str(numeric_id), f"{numeric_id}.0"
        ):
            if 0 <= numeric_id < len(encoder.classes_):
                return normalize_label(
                    encoder.classes_[numeric_id]
                )
    except (ValueError, TypeError, OverflowError):
        pass

    return direct_label


class_names = [
    get_class_name(class_id)
    for class_id in model.classes_
]

print("Interpreted model classes:", class_names)

accident_indices = [
    i for i, name in enumerate(class_names)
    if name == "accident"
]

if not accident_indices:
    print("\nERROR: Could not identify the accident class.")
    print("Model classes:", list(model.classes_))
    print("Encoder classes:", list(encoder.classes_))
    print(
        "Check that helmet_model.pkl and "
        "label_encoder.pkl were created together "
        "by the same training script."
    )
    raise SystemExit(1)

accident_probability_index = accident_indices[0]


def decode_prediction(prediction):
    """Decode a predicted class safely."""
    return get_class_name(prediction)


# ==================================================
# SHARED LIVE DATA
# ==================================================

data_lock = threading.Lock()
stop_event = threading.Event()

recent_predictions = deque(maxlen=WINDOW_SIZE)

times = deque(maxlen=GRAPH_POINTS)

ax_history = deque(maxlen=GRAPH_POINTS)
ay_history = deque(maxlen=GRAPH_POINTS)
az_history = deque(maxlen=GRAPH_POINTS)

gx_history = deque(maxlen=GRAPH_POINTS)
gy_history = deque(maxlen=GRAPH_POINTS)
gz_history = deque(maxlen=GRAPH_POINTS)

probability_history = deque(maxlen=GRAPH_POINTS)

live_data = {
    "AX": 0.0, "AY": 0.0, "AZ": 0.0,
    "GX": 0.0, "GY": 0.0, "GZ": 0.0,
    "label": "Waiting",
    "probability": 0.0,
    "accident_count": 0,
    "readings": 0,
    "alert_sent": False,
    "connection": "Connecting"
}


# ==================================================
# SERIAL READING AND LIVE PREDICTION
# ==================================================

def detection_worker():
    ser = None
    start_time = time.perf_counter()
    sample_number = 0

    try:
        ser = serial.Serial(PORT, BAUD_RATE, timeout=0.2)
        time.sleep(2)
        ser.reset_input_buffer()

        with data_lock:
            live_data["connection"] = "Connected"

        print("\nSmart Helmet Live Detection")
        print("============================")
        print("COM port:", PORT)
        print("Waiting for ESP32 IMU data...\n")

        while not stop_event.is_set():

            line = ser.readline().decode(
                "utf-8", errors="ignore"
            ).strip()

            if not line:
                continue

            values = line.split(",")

            # Expected format: AX,AY,AZ,GX,GY,GZ
            if len(values) != 6:
                continue

            try:
                ax, ay, az, gx, gy, gz = map(float, values)
            except ValueError:
                continue

            if not np.all(np.isfinite(
                [ax, ay, az, gx, gy, gz]
            )):
                continue

            # Engineered features must match model training.
            acc_mag = np.sqrt(ax**2 + ay**2 + az**2)
            gyro_mag = np.sqrt(gx**2 + gy**2 + gz**2)

            row = {
                "AX": ax,
                "AY": ay,
                "AZ": az,
                "GX": gx,
                "GY": gy,
                "GZ": gz,
                "ACC_MAG": acc_mag,
                "GYRO_MAG": gyro_mag
            }

            sample_df = pd.DataFrame(
                [row], columns=model_features
            )

            prediction = model.predict(sample_df)[0]
            label = decode_prediction(prediction)

            probabilities = model.predict_proba(sample_df)[0]

            accident_probability = float(
                probabilities[accident_probability_index]
            )

            sample_number += 1
            elapsed = time.perf_counter() - start_time

            with data_lock:

                times.append(elapsed)

                ax_history.append(ax)
                ay_history.append(ay)
                az_history.append(az)

                gx_history.append(gx)
                gy_history.append(gy)
                gz_history.append(gz)

                probability_history.append(
                    accident_probability * 100
                )

                live_data.update({
                    "AX": ax, "AY": ay, "AZ": az,
                    "GX": gx, "GY": gy, "GZ": gz,
                    "label": label,
                    "probability": accident_probability,
                    "readings": sample_number
                })

                # ----------------------------------
                # ACCIDENT CONFIRMATION
                # ----------------------------------

                if not live_data["alert_sent"]:

                    qualifies = (
                        label == "accident"
                        and accident_probability
                        >= CONFIDENCE_THRESHOLD
                    )

                    recent_predictions.append(
                        1 if qualifies else 0
                    )

                    accident_count = sum(recent_predictions)
                    live_data["accident_count"] = accident_count

                    if (
                        len(recent_predictions) == WINDOW_SIZE
                        and accident_count >= REQUIRED_ACCIDENTS
                    ):
                        print("\n!!! ACCIDENT CONFIRMED !!!")

                        try:
                            ser.write(b"A\n")
                            ser.flush()

                            live_data["alert_sent"] = True
                            recent_predictions.clear()

                            print("Command A sent to ESP32.")
                            print("Alert locked until restart.\n")

                        except serial.SerialException as error:
                            print("Failed to send command:", error)

                else:
                    live_data["accident_count"] = sum(
                        recent_predictions
                    )

            print(
                f"Reading {sample_number} | "
                f"Prediction: {label} | "
                f"Accident probability: "
                f"{accident_probability:.1%}"
            )

    except serial.SerialException as error:
        print("\nSerial connection error:", error)
        print("Check the COM port and close Arduino Serial Monitor.")

        with data_lock:
            live_data["connection"] = "Serial error"

    except Exception as error:
        print("\nDetection error:", repr(error))

        with data_lock:
            live_data["connection"] = "Detection error"

    finally:
        if ser is not None and ser.is_open:
            ser.close()

        with data_lock:
            if live_data["connection"] == "Connected":
                live_data["connection"] = "Disconnected"

        print("Serial connection closed.")


# ==================================================
# DASHBOARD: THREE SEPARATE GRAPHS
# ==================================================

fig, (ax_acc, ax_gyro, ax_prob) = plt.subplots(
    3, 1, figsize=(13, 10), sharex=True
)

fig.suptitle(
    "SMART HELMET - LIVE IMU & ACCIDENT DETECTION",
    fontsize=14,
    fontweight="bold"
)

# Accelerometer
line_ax, = ax_acc.plot([], [], label="AX")
line_ay, = ax_acc.plot([], [], label="AY")
line_az, = ax_acc.plot([], [], label="AZ")

ax_acc.set_title("Accelerometer")
ax_acc.set_ylabel("Acceleration (m/s²)")
ax_acc.legend(loc="upper right")
ax_acc.grid(True)

# Gyroscope
line_gx, = ax_gyro.plot([], [], label="GX")
line_gy, = ax_gyro.plot([], [], label="GY")
line_gz, = ax_gyro.plot([], [], label="GZ")

ax_gyro.set_title("Gyroscope")
ax_gyro.set_ylabel("Angular velocity (rad/s)")
ax_gyro.legend(loc="upper right")
ax_gyro.grid(True)

# Accident probability
line_prob, = ax_prob.plot(
    [], [], label="Accident probability (%)"
)

ax_prob.axhline(
    CONFIDENCE_THRESHOLD * 100,
    linestyle="--",
    label="Confidence threshold"
)

ax_prob.set_title("ML Accident Probability")
ax_prob.set_ylabel("Probability (%)")
ax_prob.set_xlabel("Elapsed time (seconds)")
ax_prob.set_ylim(0, 100)
ax_prob.legend(loc="upper right")
ax_prob.grid(True)

live_text = fig.text(
    0.02, 0.01, "",
    fontsize=9,
    family="monospace"
)

fig.tight_layout(rect=[0, 0.08, 1, 0.95])


def update_dashboard(_frame):

    with data_lock:
        t = list(times)

        ax_values = list(ax_history)
        ay_values = list(ay_history)
        az_values = list(az_history)

        gx_values = list(gx_history)
        gy_values = list(gy_history)
        gz_values = list(gz_history)

        prob_values = list(probability_history)
        current = live_data.copy()

    if not t:
        live_text.set_text(
            "Waiting for IMU data... | "
            + current["connection"]
        )
        return

    line_ax.set_data(t, ax_values)
    line_ay.set_data(t, ay_values)
    line_az.set_data(t, az_values)

    line_gx.set_data(t, gx_values)
    line_gy.set_data(t, gy_values)
    line_gz.set_data(t, gz_values)

    line_prob.set_data(t, prob_values)

    right = t[-1]
    left = max(0, right - 10)

    for axis in (ax_acc, ax_gyro, ax_prob):
        axis.set_xlim(left, max(right, left + 1))

    ax_acc.relim()
    ax_acc.autoscale_view(scalex=False, scaley=True)

    ax_gyro.relim()
    ax_gyro.autoscale_view(scalex=False, scaley=True)

    status = (
        "ALERT SENT"
        if current["alert_sent"]
        else "Monitoring"
    )

    live_text.set_text(
        f"AX={current['AX']:+.3f}  "
        f"AY={current['AY']:+.3f}  "
        f"AZ={current['AZ']:+.3f} m/s²\n"
        f"GX={current['GX']:+.3f}  "
        f"GY={current['GY']:+.3f}  "
        f"GZ={current['GZ']:+.3f} rad/s\n"
        f"Prediction: {current['label'].upper()} | "
        f"Accident probability: {current['probability']:.1%} | "
        f"Confirmations: {current['accident_count']}/{WINDOW_SIZE}\n"
        f"Connection: {current['connection']} | "
        f"Readings: {current['readings']} | Status: {status}"
    )


# ==================================================
# RUN
# ==================================================

if __name__ == "__main__":

    worker = threading.Thread(
        target=detection_worker,
        daemon=True
    )
    worker.start()

    animation = FuncAnimation(
        fig,
        update_dashboard,
        interval=GRAPH_REFRESH_MS,
        blit=False,
        cache_frame_data=False
    )

    try:
        plt.show()
    finally:
        stop_event.set()
        worker.join(timeout=2)
        print("Live detection stopped.")
