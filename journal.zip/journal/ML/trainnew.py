import pandas as pd
import numpy as np
import joblib

from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

# Use the CSV file in the same folder as this script
BASE_DIR = Path(__file__).resolve().parent
DATASET_PATH = BASE_DIR / "datasetnew.csv"

df = pd.read_csv(DATASET_PATH)

print("Dataset loaded:", df.shape)

features = ["AX", "AY", "AZ", "GX", "GY", "GZ"]

# Convert sensor data to numeric
df[features] = df[features].apply(
    pd.to_numeric, errors="coerce"
)

df["Label"] = df["Label"].astype(str).str.strip().str.lower()
df = df.dropna(subset=features + ["Label"])

# Feature engineering
df["ACC_MAG"] = np.sqrt(
    df["AX"]**2 + df["AY"]**2 + df["AZ"]**2
)

df["GYRO_MAG"] = np.sqrt(
    df["GX"]**2 + df["GY"]**2 + df["GZ"]**2
)

model_features = features + ["ACC_MAG", "GYRO_MAG"]

X = df[model_features]
y_text = df["Label"]

encoder = LabelEncoder()
y = encoder.fit_transform(y_text)

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

model = RandomForestClassifier(
    n_estimators=200,
    random_state=42,
    class_weight="balanced",
    n_jobs=-1
)

model.fit(X_train, y_train)

predictions = model.predict(X_test)

print("\nAccuracy:",
      round(accuracy_score(y_test, predictions) * 100, 2), "%")

print("\nClassification Report:")
print(classification_report(
    y_test,
    predictions,
    labels=np.arange(len(encoder.classes_)),
    target_names=encoder.classes_,
    zero_division=0
))

print("Confusion Matrix:")
print(confusion_matrix(y_test, predictions))

# Save model and its required feature names
joblib.dump(model, BASE_DIR / "helmet_model.pkl")
joblib.dump(encoder, BASE_DIR / "label_encoder.pkl")
joblib.dump(model_features, BASE_DIR / "model_features.pkl")

print("\nModel, encoder and feature list saved successfully.")
