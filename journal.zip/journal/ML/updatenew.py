import time
import socket
import threading
import csv
from pathlib import Path
from collections import deque
from datetime import datetime

import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# Smart Helmet Wi-Fi TCP live detection
# ESP32 sends: AX,AY,AZ,GX,GY,GZ\n
BASE_DIR = Path(__file__).resolve().parent
HOST = "0.0.0.0"
PORT = 5000
CONFIDENCE_THRESHOLD = 0.80
WINDOW_SIZE = 10
REQUIRED_ACCIDENTS = 5
GRAPH_POINTS = 200
GRAPH_REFRESH_MS = 100
SOCKET_TIMEOUT = 1.0

MODEL_PATH = BASE_DIR / "helmet_model.pkl"
ENCODER_PATH = BASE_DIR / "label_encoder.pkl"
FEATURES_PATH = BASE_DIR / "model_features.pkl"
LOG_PATH = BASE_DIR / "wifi_detection_log.csv"

try:
    model = joblib.load(MODEL_PATH)
    encoder = joblib.load(ENCODER_PATH)
    model_features = list(joblib.load(FEATURES_PATH))
    print("\\n" + "=" * 68)
    print("SMART HELMET SYSTEM | EDGE-AI ACCIDENT MONITORING")
    print("=" * 68)
    print("[OK] Machine-learning model files loaded.")
except FileNotFoundError as error:
    raise SystemExit(
        f"Missing model file: {error}\nPut helmet_model.pkl, label_encoder.pkl, "
        "and model_features.pkl in the same folder as this script."
    )

if not hasattr(model, "predict_proba"):
    raise SystemExit("Error: saved model must support predict_proba().")

expected_features = {"AX", "AY", "AZ", "GX", "GY", "GZ", "ACC_MAG", "GYRO_MAG"}
if set(model_features) != expected_features:
    raise SystemExit(
        f"Unexpected model features: {model_features}\n"
        "This script expects AX, AY, AZ, GX, GY, GZ, ACC_MAG, GYRO_MAG. "
        "Use the exact features from your training code."
    )

def normalize_label(value):
    return str(value).strip().lower()

def get_class_name(class_id):
    try:
        return normalize_label(encoder.inverse_transform(np.asarray([class_id]))[0])
    except (ValueError, TypeError, IndexError):
        pass
    direct = normalize_label(class_id)
    if direct in ("accident", "normal"):
        return direct
    try:
        numeric_id = int(class_id)
        if str(class_id).strip() in (str(numeric_id), f"{numeric_id}.0"):
            if 0 <= numeric_id < len(encoder.classes_):
                return normalize_label(encoder.classes_[numeric_id])
    except (ValueError, TypeError, OverflowError):
        pass
    return direct

class_names = [get_class_name(class_id) for class_id in model.classes_]
print("[INFO] Model classes:", ", ".join(class_names))
accident_indices = [i for i, name in enumerate(class_names) if name == "accident"]
if not accident_indices:
    raise SystemExit(
        "Could not identify the accident class. Check that helmet_model.pkl and "
        "label_encoder.pkl were saved together by the same training script."
    )
accident_probability_index = accident_indices[0]

data_lock = threading.Lock()
stop_event = threading.Event()
recent_predictions = deque(maxlen=WINDOW_SIZE)
times = deque(maxlen=GRAPH_POINTS)
ax_history = deque(maxlen=GRAPH_POINTS)
ay_history = deque(maxlen=GRAPH_POINTS)
az_history = deque(maxlen=GRAPH_POINTS)
gx_history = deque(maxlen=GRAPH_POINTS)
gy_history = deque(maxlen=GRAPH_POINTS)
gz_history = deque(maxlen=GRAPH_POINTS)
probability_history = deque(maxlen=GRAPH_POINTS)
start_time = time.perf_counter()
log_lock = threading.Lock()

live_data = {
    "AX": 0.0, "AY": 0.0, "AZ": 0.0, "GX": 0.0, "GY": 0.0, "GZ": 0.0,
    "label": "Waiting", "probability": 0.0, "accident_count": 0,
    "readings": 0, "alert_sent": False, "connection": "Starting server",
    "last_inference_ms": 0.0,
    "helmet_status": "WAITING FOR SENSOR DATA",
}

def initialise_log():
    if not LOG_PATH.exists():
        with LOG_PATH.open("w", newline="", encoding="utf-8") as file:
            csv.writer(file).writerow([
                "timestamp", "reading", "AX", "AY", "AZ", "GX", "GY", "GZ",
                "prediction", "accident_probability", "inference_ms",
                "confirmations", "command_sent"
            ])

def log_result(row):
    with log_lock:
        with LOG_PATH.open("a", newline="", encoding="utf-8") as file:
            csv.writer(file).writerow(row)

def predict_sample(values):
    ax, ay, az, gx, gy, gz = values
    row = {
        "AX": ax, "AY": ay, "AZ": az, "GX": gx, "GY": gy, "GZ": gz,
        "ACC_MAG": float(np.sqrt(ax**2 + ay**2 + az**2)),
        "GYRO_MAG": float(np.sqrt(gx**2 + gy**2 + gz**2)),
    }
    sample_df = pd.DataFrame([row], columns=model_features)
    started = time.perf_counter()
    prediction = model.predict(sample_df)[0]
    probabilities = model.predict_proba(sample_df)[0]
    inference_ms = (time.perf_counter() - started) * 1000.0
    return get_class_name(prediction), float(probabilities[accident_probability_index]), inference_ms

def handle_client(conn, address):
    print("\\n" + "-" * 68)
    print("[CONNECTED] Helmet ESP32 is sending live sensor data.")
    print(f"[INFO] Device address: {address[0]}:{address[1]}")
    print("[INFO] AI accident monitoring has started.")
    print("-" * 68)
    conn.settimeout(SOCKET_TIMEOUT)
    buffer = b""
    sample_number = 0
    recent_predictions.clear()
    last_sample_received = time.monotonic()
    no_data_announced = False
    with data_lock:
        live_data["connection"] = f"Wi-Fi connected: {address[0]}"
        live_data["helmet_status"] = "CONNECTED - WAITING FOR HELMET SENSOR DATA"
    try:
        while not stop_event.is_set():
            try:
                chunk = conn.recv(1024)
            except socket.timeout:
                # The ESP32 may stay connected while FSR release stops sensor packets.
                if time.monotonic() - last_sample_received >= 0.2 and not no_data_announced:
                    no_data_announced = True
                    recent_predictions.clear()
                    with data_lock:
                        live_data["helmet_status"] = "NO SENSOR DATA - CHECK FSR / HELMET"
                        live_data["label"] = "Waiting"
                        live_data["probability"] = 0.0
                        live_data["accident_count"] = 0
                    print("\\n[NO SENSOR DATA] No new IMU samples for 0.2 seconds.")
                    print("[INFO] FSR may be released, helmet may be off, or sensor transmission may have stopped.")
                    print("[INFO] Wi-Fi can remain connected; this is not necessarily a network disconnection.")
                continue
            if not chunk:
                print("\\n[DISCONNECTED] ESP32 closed the Wi-Fi connection.")
                break
            buffer += chunk
            while b"\n" in buffer:
                raw_line, buffer = buffer.split(b"\n", 1)
                line = raw_line.decode("utf-8", errors="ignore").strip()
                if not line:
                    continue
                parts = line.split(",")
                if len(parts) != 6:
                    print("[WARNING] Sensor packet skipped: expected 6 comma-separated values.")
                    continue
                try:
                    values = [float(part.strip()) for part in parts]
                except ValueError:
                    print("[WARNING] Sensor packet skipped: values were not numeric.")
                    continue
                if not np.all(np.isfinite(values)):
                    continue
                ax, ay, az, gx, gy, gz = values
                last_sample_received = time.monotonic()
                no_data_announced = False
                try:
                    label, accident_probability, inference_ms = predict_sample(values)
                except Exception as error:
                    print("[ERROR] AI prediction failed:", repr(error))
                    continue

                sample_number += 1
                qualifies = label == "accident" and accident_probability >= CONFIDENCE_THRESHOLD
                with data_lock:
                    times.append(time.perf_counter() - start_time)
                    ax_history.append(ax); ay_history.append(ay); az_history.append(az)
                    gx_history.append(gx); gy_history.append(gy); gz_history.append(gz)
                    probability_history.append(accident_probability * 100.0)
                    if not live_data["alert_sent"]:
                        recent_predictions.append(1 if qualifies else 0)
                    accident_count = sum(recent_predictions)
                    live_data.update({
                        "AX": ax, "AY": ay, "AZ": az, "GX": gx, "GY": gy, "GZ": gz,
                        "label": label, "probability": accident_probability,
                        "accident_count": accident_count,
                        "readings": live_data["readings"] + 1,
                        "last_inference_ms": inference_ms,
                        "helmet_status": "HELMET WORN / LIVE SENSOR DATA",
                    })
                    should_alert = (
                        not live_data["alert_sent"]
                        and len(recent_predictions) == WINDOW_SIZE
                        and accident_count >= REQUIRED_ACCIDENTS
                    )
                    if should_alert:
                        live_data["alert_sent"] = True
                        recent_predictions.clear()
                        live_data["accident_count"] = 0

                command_sent = False
                if should_alert:
                    try:
                        conn.sendall(b"A\n")
                        command_sent = True
                        print("\n!!! ACCIDENT CONFIRMED !!!")
                        print("Sent command A to ESP32 over Wi-Fi. Alert latched until restart.\n")
                    except OSError as error:
                        print("[ERROR] Accident command could not be sent to ESP32:", error)

                log_result([
                    datetime.now().isoformat(timespec="milliseconds"), sample_number,
                    ax, ay, az, gx, gy, gz, label, round(accident_probability, 6),
                    round(inference_ms, 3), accident_count, int(command_sent)
                ])
                print(
                    f"[LIVE] Sample {live_data['readings']:05d} | "
                    f"AI result: {label.upper():8s} | "
                    f"Accident probability: {accident_probability:6.1%} | "
                    f"Qualified samples: {accident_count}/{WINDOW_SIZE} | "
                    f"AI processing: {inference_ms:.2f} ms"
                )
    except OSError as error:
        print("[NETWORK ERROR] Wi-Fi/TCP connection problem:", error)
    finally:
        try:
            conn.close()
        except OSError:
            pass
        with data_lock:
            live_data["connection"] = "Waiting for ESP32"
        print("[INFO] Waiting for the ESP32 to reconnect.")

def server_worker():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server.bind((HOST, PORT))
        server.listen(1)
        server.settimeout(1.0)
        print("\nSMART HELMET - Wi-Fi LIVE DETECTION")
        print("===================================")
        print(f"TCP server listening on port {PORT}")
        print("Run ipconfig in Windows and set the laptop IPv4 address in the ESP32 code.")
        print("Waiting for ESP32 connection...\n")
        with data_lock:
            live_data["connection"] = "Waiting for ESP32"
        while not stop_event.is_set():
            try:
                conn, address = server.accept()
            except socket.timeout:
                continue
            handle_client(conn, address)
    except OSError as error:
        print(f"[SERVER ERROR] Could not start TCP server on port {PORT}: {error}")
        print("[FIX] Check if another program uses this port and review Windows Firewall permissions.")
        with data_lock:
            live_data["connection"] = "Server error"
    finally:
        server.close()

# Dashboard: three live graphs
fig, (ax_acc, ax_gyro, ax_prob) = plt.subplots(3, 1, figsize=(14, 11), sharex=True)
fig.suptitle("SMART HELMET - Wi-Fi LIVE IMU & ACCIDENT DETECTION", fontsize=14, fontweight="bold")
line_ax, = ax_acc.plot([], [], label="AX")
line_ay, = ax_acc.plot([], [], label="AY")
line_az, = ax_acc.plot([], [], label="AZ")
ax_acc.set_title("Accelerometer")
ax_acc.set_ylabel("Acceleration (m/s²)")
ax_acc.legend(loc="upper right"); ax_acc.grid(True)
line_gx, = ax_gyro.plot([], [], label="GX")
line_gy, = ax_gyro.plot([], [], label="GY")
line_gz, = ax_gyro.plot([], [], label="GZ")
ax_gyro.set_title("Gyroscope")
ax_gyro.set_ylabel("Angular velocity (rad/s)")
ax_gyro.legend(loc="upper right"); ax_gyro.grid(True)
line_prob, = ax_prob.plot([], [], label="Accident probability (%)")
ax_prob.axhline(CONFIDENCE_THRESHOLD * 100, linestyle="--", label="Confidence threshold")
ax_prob.set_title("ML Accident Probability")
ax_prob.set_ylabel("Probability (%)")
ax_prob.set_xlabel("Elapsed time (seconds)")
ax_prob.set_ylim(0, 100)
ax_prob.legend(loc="upper right"); ax_prob.grid(True)
live_text = fig.text(0.025, 0.005, "", fontsize=8.5, family="monospace", va="bottom")
fig.tight_layout(rect=[0, 0.21, 1, 0.95])

def update_dashboard(_frame):
    with data_lock:
        t = list(times)
        ax_values, ay_values, az_values = list(ax_history), list(ay_history), list(az_history)
        gx_values, gy_values, gz_values = list(gx_history), list(gy_history), list(gz_history)
        prob_values = list(probability_history)
        current = live_data.copy()
    if not t:
        live_text.set_text(
            f"Wi-Fi connection: {current['connection']}\\n"
            f"HELMET STATUS: {current['helmet_status']}\\n"
            "Check FSR pressure, ESP32 sensor output and Wi-Fi connection."
        )
        return
    line_ax.set_data(t, ax_values); line_ay.set_data(t, ay_values); line_az.set_data(t, az_values)
    line_gx.set_data(t, gx_values); line_gy.set_data(t, gy_values); line_gz.set_data(t, gz_values)
    line_prob.set_data(t, prob_values)
    right = t[-1]; left = max(0, right - 10)
    for axis in (ax_acc, ax_gyro, ax_prob):
        axis.set_xlim(left, max(right, left + 1))
    ax_acc.relim(); ax_acc.autoscale_view(scalex=False, scaley=True)
    ax_gyro.relim(); ax_gyro.autoscale_view(scalex=False, scaley=True)
    if current["alert_sent"]:
        status = "EMERGENCY COMMAND SENT TO ESP32"
        explanation = "At least 5 of the latest 10 samples met the accident confidence rule."
    elif current["helmet_status"] != "HELMET WORN / LIVE SENSOR DATA":
        status = "WAITING - NO NEW SENSOR DATA"
        explanation = "No new IMU samples are arriving. Check the FSR and helmet-worn condition."
    else:
        status = "MONITORING - NO EMERGENCY COMMAND SENT"
        explanation = "An alert needs at least 5 accident predictions in the latest 10 samples, each at >=80% probability."

    live_text.set_text(
        f"SYSTEM STATUS: {status}\\n"
        f"HELMET STATUS: {current['helmet_status']}\\n"
        f"AI DECISION: {current['label'].upper()} | Estimated accident probability: {current['probability']:.1%}\\n"
        f"ALERT RULE: {current['accident_count']}/{WINDOW_SIZE} qualifying samples "
        f"(need {REQUIRED_ACCIDENTS}/{WINDOW_SIZE})\\n"
        f"Wi-Fi: {current['connection']} | Total samples: {current['readings']} | "
        f"AI processing: {current['last_inference_ms']:.2f} ms\\n"
        f"Accelerometer (m/s²): AX {current['AX']:+.2f}, AY {current['AY']:+.2f}, AZ {current['AZ']:+.2f}\\n"
        f"Gyroscope (rad/s): GX {current['GX']:+.2f}, GY {current['GY']:+.2f}, GZ {current['GZ']:+.2f}\\n"
        f"EXPLANATION: Probability is the model's estimate, not proof of an accident. {explanation}"
    )


if __name__ == "__main__":
    initialise_log()
    worker = threading.Thread(target=server_worker, daemon=True)
    worker.start()
    animation = FuncAnimation(fig, update_dashboard, interval=GRAPH_REFRESH_MS, blit=False, cache_frame_data=False)
    try:
        plt.show()
    except KeyboardInterrupt:
        pass
    finally:
        stop_event.set()
        worker.join(timeout=3)
        print("\\n[STOPPED] Smart Helmet live monitoring has stopped.")
        print(f"[SAVED] Sensor and AI results log: {LOG_PATH}")
