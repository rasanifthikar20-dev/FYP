"""
Smart Helmet - Machine Learning Algorithm Comparison
Compares Random Forest, Decision Tree, KNN, SVM and Logistic Regression.

Uses the same dataset, engineered features and stratified train/test split
for every algorithm. Saves comparison_results.csv and accuracy_comparison.png.
Also saves a confusion matrix for each algorithm.

Run:
    pip install pandas numpy matplotlib seaborn scikit-learn
    python compare_algorithms.py
"""

from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

warnings.filterwarnings("ignore", category=UserWarning)

BASE_DIR = Path(__file__).resolve().parent
DATASET_PATH = BASE_DIR / "datasetnew.csv"
RANDOM_STATE = 42
TEST_SIZE = 0.20

# 1. Load and clean dataset
df = pd.read_csv(DATASET_PATH)
df.columns = df.columns.str.strip().str.upper()

required_columns = ["AX", "AY", "AZ", "GX", "GY", "GZ", "LABEL"]
missing = [col for col in required_columns if col not in df.columns]
if missing:
    raise ValueError(f"Missing required columns in dataset: {missing}")

sensor_features = ["AX", "AY", "AZ", "GX", "GY", "GZ"]
df[sensor_features] = df[sensor_features].apply(
    pd.to_numeric, errors="coerce"
)
df["LABEL"] = df["LABEL"].astype(str).str.strip().str.lower()

df = df.dropna(subset=sensor_features + ["LABEL"]).copy()

# 2. Feature engineering - same eight features as your Random Forest project
df["ACC_MAG"] = np.sqrt(
    df["AX"] ** 2 + df["AY"] ** 2 + df["AZ"] ** 2
)
df["GYRO_MAG"] = np.sqrt(
    df["GX"] ** 2 + df["GY"] ** 2 + df["GZ"] ** 2
)

feature_names = sensor_features + ["ACC_MAG", "GYRO_MAG"]
X = df[feature_names]
y_text = df["LABEL"]

encoder = LabelEncoder()
y = encoder.fit_transform(y_text)

print("=" * 60)
print("SMART HELMET - ALGORITHM COMPARISON")
print("=" * 60)
print(f"Dataset rows used: {len(df)}")
print("Class distribution:")
print(df["LABEL"].value_counts().to_string())
print("Features:", ", ".join(feature_names))
print("Classes:", list(encoder.classes_))

# 3. One common split for all algorithms
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=TEST_SIZE,
    random_state=RANDOM_STATE,
    stratify=y
)

# 4. Define algorithms
# Random Forest settings match your trainnew.py.
models = {
    "Random Forest": RandomForestClassifier(
        n_estimators=200,
        random_state=RANDOM_STATE,
        class_weight="balanced",
        n_jobs=-1
    ),
    "Decision Tree": DecisionTreeClassifier(
        random_state=RANDOM_STATE,
        class_weight="balanced"
    ),
    "KNN": make_pipeline(
        StandardScaler(),
        KNeighborsClassifier(n_neighbors=5)
    ),
    "SVM": make_pipeline(
        StandardScaler(),
        SVC(kernel="rbf", class_weight="balanced")
    ),
    "Logistic Regression": make_pipeline(
        StandardScaler(),
        LogisticRegression(
            max_iter=2000,
            class_weight="balanced",
            random_state=RANDOM_STATE
        )
    )
}

# 5. Train and evaluate each model
results = []
class_names = list(encoder.classes_)

for name, model in models.items():
    print(f"\nTraining {name} ...")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    acc = accuracy_score(y_test, y_pred) * 100
    precision = precision_score(
        y_test, y_pred, average="weighted", zero_division=0
    ) * 100
    recall = recall_score(
        y_test, y_pred, average="weighted", zero_division=0
    ) * 100
    f1 = f1_score(
        y_test, y_pred, average="weighted", zero_division=0
    ) * 100

    results.append({
        "Algorithm": name,
        "Accuracy (%)": acc,
        "Precision (%)": precision,
        "Recall (%)": recall,
        "F1-score (%)": f1
    })

    print(f"Accuracy:  {acc:.2f}%")
    print(f"Precision: {precision:.2f}%")
    print(f"Recall:    {recall:.2f}%")
    print(f"F1-score:  {f1:.2f}%")
    print("\nClassification report:")
    print(classification_report(
        y_test,
        y_pred,
        labels=np.arange(len(class_names)),
        target_names=class_names,
        zero_division=0
    ))

    # Save one confusion matrix per algorithm
    cm = confusion_matrix(
        y_test, y_pred, labels=np.arange(len(class_names))
    )
    safe_name = name.lower().replace(" ", "_")
    plt.figure(figsize=(6, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=class_names,
        yticklabels=class_names
    )
    plt.title(f"{name} - Confusion Matrix")
    plt.xlabel("Predicted Label")
    plt.ylabel("Actual Label")
    plt.tight_layout()
    plt.savefig(BASE_DIR / f"confusion_matrix_{safe_name}.png", dpi=300)
    plt.close()

# 6. Save comparison table
results_df = pd.DataFrame(results)
results_df = results_df.sort_values(
    by=["F1-score (%)", "Recall (%)", "Accuracy (%)"],
    ascending=False
)
results_path = BASE_DIR / "comparison_results.csv"
results_df.to_csv(results_path, index=False)

print("\n" + "=" * 60)
print("FINAL COMPARISON (ranked by weighted F1-score)")
print("=" * 60)
print(results_df.round(2).to_string(index=False))

# 7. Accuracy comparison graph
plot_df = results_df.sort_values("Accuracy (%)", ascending=False)
plt.figure(figsize=(10, 6))
bars = plt.bar(plot_df["Algorithm"], plot_df["Accuracy (%)"])
plt.ylabel("Testing Accuracy (%)")
plt.xlabel("Machine Learning Algorithm")
plt.title("Smart Helmet - Testing Accuracy Comparison")
plt.ylim(0, 105)
plt.xticks(rotation=20, ha="right")

for bar, value in zip(bars, plot_df["Accuracy (%)"]):
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        bar.get_height() + 1,
        f"{value:.2f}%",
        ha="center",
        va="bottom"
    )

plt.tight_layout()
accuracy_graph_path = BASE_DIR / "accuracy_comparison.png"
plt.savefig(accuracy_graph_path, dpi=300)
plt.close()

# 8. Plot weighted F1-score comparison
plt.figure(figsize=(10, 6))
f1_df = results_df.sort_values("F1-score (%)", ascending=False)
bars = plt.bar(f1_df["Algorithm"], f1_df["F1-score (%)"])
plt.ylabel("Weighted F1-score (%)")
plt.xlabel("Machine Learning Algorithm")
plt.title("Smart Helmet - Weighted F1-score Comparison")
plt.ylim(0, 105)
plt.xticks(rotation=20, ha="right")

for bar, value in zip(bars, f1_df["F1-score (%)"]):
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        bar.get_height() + 1,
        f"{value:.2f}%",
        ha="center",
        va="bottom"
    )

plt.tight_layout()
plt.savefig(BASE_DIR / "f1_comparison.png", dpi=300)
plt.close()

print("\nFiles saved in:", BASE_DIR)
print("- comparison_results.csv")
print("- accuracy_comparison.png")
print("- f1_comparison.png")
print("- confusion_matrix_<algorithm>.png")

best = results_df.iloc[0]
print(
    f"\nHighest weighted F1-score in this run: "
    f"{best['Algorithm']} ({best['F1-score (%)']:.2f}%)"
)
print(
    "\nImportant: choose Random Forest only if the results and "
    "your project requirements support that decision. "
    "This random row split is a preliminary comparison; "
    "testing by separate recording/session is stronger if session IDs exist."
)
