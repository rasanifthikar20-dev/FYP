
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report
)
from sklearn.preprocessing import LabelEncoder

# Project folder
BASE_DIR = Path(__file__).resolve().parent

# Load dataset
df = pd.read_csv(BASE_DIR / "datasetnew.csv")

# Select sensor features
features = ["AX", "AY", "AZ", "GX", "GY", "GZ"]

df[features] = df[features].apply(
    pd.to_numeric, errors="coerce"
)

df["Label"] = df["Label"].astype(str).str.strip().str.lower()

df = df.dropna(subset=features + ["Label"])

# Feature engineering
df["ACC_MAG"] = np.sqrt(
    df["AX"]**2 + df["AY"]**2 + df["AZ"]**2
)

df["GYRO_MAG"] = np.sqrt(
    df["GX"]**2 + df["GY"]**2 + df["GZ"]**2
)

model_features = features + ["ACC_MAG", "GYRO_MAG"]

X = df[model_features]
y = df["Label"]

# Encode labels
encoder = LabelEncoder()
y_encoded = encoder.fit_transform(y)

# Split dataset: 80% training, 20% testing
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y_encoded,
    test_size=0.20,
    random_state=42,
    stratify=y_encoded
)

# Random Forest model (same settings as trainnew.py)
model = RandomForestClassifier(
    n_estimators=200,
    random_state=42,
    class_weight="balanced",
    n_jobs=-1
)

# Train model
model.fit(X_train, y_train)

# Predictions
train_pred = model.predict(X_train)
test_pred = model.predict(X_test)

# Calculate accuracy
train_accuracy = accuracy_score(
    y_train, train_pred
) * 100

test_accuracy = accuracy_score(
    y_test, test_pred
) * 100

print("\n========== MODEL ACCURACY ==========")
print(f"Training Accuracy: {train_accuracy:.2f}%")
print(f"Testing Accuracy:  {test_accuracy:.2f}%")

# Classification report
print("\nClassification Report:")
print(classification_report(
    y_test,
    test_pred,
    labels=np.arange(len(encoder.classes_)),
    target_names=encoder.classes_,
    zero_division=0
))

# Accuracy graph
plt.figure(figsize=(8, 5))

labels = ["Training Accuracy", "Testing Accuracy"]
values = [train_accuracy, test_accuracy]

bars = plt.bar(labels, values)

plt.title("Smart Helmet - Random Forest Accuracy")
plt.ylabel("Accuracy (%)")
plt.ylim(0, 105)
plt.grid(axis="y", linestyle="--", alpha=0.4)

for bar, value in zip(bars, values):
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        value + 1,
        f"{value:.2f}%",
        ha="center",
        fontsize=11
    )

plt.tight_layout()
plt.savefig(
    BASE_DIR / "accuracy_graph.png",
    dpi=300
)
plt.show()

# Confusion matrix
cm = confusion_matrix(
    y_test,
    test_pred,
    labels=np.arange(len(encoder.classes_))
)

plt.figure(figsize=(7, 5))

sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=encoder.classes_,
    yticklabels=encoder.classes_
)

plt.title("Smart Helmet - Confusion Matrix")
plt.xlabel("Predicted Label")
plt.ylabel("Actual Label")
plt.tight_layout()

plt.savefig(
    BASE_DIR / "confusion_matrix.png",
    dpi=300
)

plt.show()

print("\nAccuracy graph and confusion matrix saved!")
