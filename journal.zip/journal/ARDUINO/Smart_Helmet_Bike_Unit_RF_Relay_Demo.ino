/*
  SMART HELMET - BIKE UNIT (RF + RELAY DEMONSTRATION)
  Board: ESP32 DevKit V1
  Radio: NRF24L01
  Relay: low-voltage bench demonstration only

  Expected helmet-unit messages:
    HELMET_001:HELMET_WORN
    HELMET_001:ACCIDENT

  NRF24L01 wiring:
    VCC  -> 3.3V ONLY
    GND  -> GND
    CE   -> GPIO4
    CSN  -> GPIO5
    SCK  -> GPIO18
    MISO -> GPIO19
    MOSI -> GPIO23

  Demo relay module:
    IN   -> GPIO25
    VCC/GND -> according to relay board specifications
  Ensure ESP32 and receiver share GND if the module requires it.

  IMPORTANT:
  - Do not connect this unvalidated circuit to a real motorcycle ignition.
  - Test relay behavior with a low-voltage lamp or other safe test load only.
  - Many relay modules are active-LOW. Set RELAY_ACTIVE_LOW to match your board.
  - This is not a certified vehicle safety controller.
*/

#include <SPI.h>
#include <RF24.h>
#include <string.h>

RF24 radio(4, 5);                 // CE, CSN
const byte RF_ADDRESS[6] = "A1001";
const uint8_t RF_CHANNEL = 100;

const char HELMET_ID[] = "HELMET_001";
const int RELAY_PIN = 25;
const int STATUS_LED_PIN = 2;
const int BUZZER_PIN = 13;

// Set true for an active-LOW relay board; false for active-HIGH.
// Verify the relay module's input behavior before connecting a test load.
const bool RELAY_ACTIVE_LOW = true;

// A worn packet must keep arriving; otherwise relay output is disabled.
const unsigned long HELMET_TIMEOUT_MS = 2000;
const unsigned long ACCIDENT_BUZZER_MS = 3000;
const unsigned long STATUS_INTERVAL_MS = 3000;

bool radioReady = false;
bool helmetConfirmedWorn = false;
bool accidentSeen = false;
bool buzzerOn = false;

unsigned long lastWornPacketMs = 0;
unsigned long buzzerStartMs = 0;
unsigned long lastStatusMs = 0;
unsigned long packetsReceived = 0;

void setRelay(bool enabled) {
  // enabled=true energizes the relay coil; enabled=false de-energizes it.
  // Use only for a safe low-voltage demo load.
  if (RELAY_ACTIVE_LOW) {
    digitalWrite(RELAY_PIN, enabled ? LOW : HIGH);
  } else {
    digitalWrite(RELAY_PIN, enabled ? HIGH : LOW);
  }
}

void stopBuzzer() {
  digitalWrite(BUZZER_PIN, LOW);
  buzzerOn = false;
}

void startBuzzer() {
  digitalWrite(BUZZER_PIN, HIGH);
  buzzerStartMs = millis();
  buzzerOn = true;
}

void showStatus(const char* reason) {
  Serial.println();
  Serial.println("========== BIKE UNIT STATUS ==========");
  Serial.print("Reason: ");
  Serial.println(reason);
  Serial.print("NRF24L01: ");
  Serial.println(radioReady ? "READY" : "ERROR");
  Serial.print("Helmet worn confirmed: ");
  Serial.println(helmetConfirmedWorn ? "YES" : "NO");
  Serial.print("Relay command: ");
  Serial.println(helmetConfirmedWorn && !accidentSeen ? "ON (demo output)" : "OFF");
  Serial.print("Accident message seen: ");
  Serial.println(accidentSeen ? "YES" : "NO");
  Serial.print("RF packets received: ");
  Serial.println(packetsReceived);
  Serial.println("======================================");
}

void processRFMessage(const char* message) {
  char wornMessage[32];
  char accidentMessage[32];

  snprintf(wornMessage, sizeof(wornMessage), "%s:HELMET_WORN", HELMET_ID);
  snprintf(accidentMessage, sizeof(accidentMessage), "%s:ACCIDENT", HELMET_ID);

  Serial.print("[RF] Received: ");
  Serial.println(message);

  if (strcmp(message, wornMessage) == 0) {
    // A valid worn packet renews the timeout.
    lastWornPacketMs = millis();
    helmetConfirmedWorn = true;

    if (!accidentSeen) {
      setRelay(true);
      digitalWrite(STATUS_LED_PIN, HIGH);
      Serial.println("[STATUS] HELMET WORN: valid RF packet received.");
      Serial.println("[RELAY] ON - low-voltage demo output energized.");
    } else {
      // Require a reset/restart after an accident for this demo.
      setRelay(false);
      Serial.println("[STATUS] Accident already seen; relay remains OFF.");
    }
  } else if (strcmp(message, accidentMessage) == 0) {
    accidentSeen = true;
    helmetConfirmedWorn = false;

    setRelay(false);
    digitalWrite(STATUS_LED_PIN, LOW);
    startBuzzer();

    Serial.println();
    Serial.println("**************************************");
    Serial.println("[EMERGENCY] ACCIDENT MESSAGE RECEIVED");
    Serial.println("[RELAY] OFF - demo output de-energized.");
    Serial.println("[BUZZER] ON for 3 seconds.");
    Serial.println("**************************************");
  } else {
    Serial.println("[WARNING] Unknown message or helmet ID; ignored.");
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(RELAY_PIN, OUTPUT);
  pinMode(STATUS_LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  // Force relay output to inactive state at startup.
  setRelay(false);
  digitalWrite(STATUS_LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  Serial.println();
  Serial.println("======================================");
  Serial.println(" SMART HELMET - BIKE UNIT RF RECEIVER");
  Serial.println("======================================");
  Serial.println("[INFO] Helmet ID: HELMET_001");
  Serial.println("[INFO] RF address: A1001");
  Serial.println("[INFO] RF channel: 100; data rate: 250KBPS");
  Serial.println("[INFO] Relay starts OFF.");
  Serial.println("[INFO] Low-voltage bench demo only.");

  SPI.begin(18, 19, 23, 5);
  delay(100);

  radioReady = radio.begin();
  if (!radioReady) {
    Serial.println("[ERROR] NRF24L01 NOT FOUND.");
    Serial.println("[CHECK] 3.3V, GND, CE=4, CSN=5, SCK=18, MISO=19, MOSI=23.");
    setRelay(false);
    while (true) {
      digitalWrite(STATUS_LED_PIN, !digitalRead(STATUS_LED_PIN));
      delay(250);
    }
  }

  radio.setChannel(RF_CHANNEL);
  radio.setDataRate(RF24_250KBPS);
  radio.setPALevel(RF24_PA_LOW);
  radio.setRetries(5, 15);
  radio.openReadingPipe(1, RF_ADDRESS);
  radio.startListening();

  Serial.println("[OK] NRF24L01 initialized.");
  Serial.println("[READY] Waiting for HELMET_WORN packets...");
  showStatus("Startup: relay OFF");
}

void loop() {
  // Read incoming radio messages.
  while (radioReady && radio.available()) {
    char message[32] = {0};
    radio.read(message, sizeof(message));
    message[sizeof(message) - 1] = '\0';
    packetsReceived++;
    processRFMessage(message);
  }

  // If no repeated HELMET_WORN packet arrives, fail safe to relay OFF.
  if (helmetConfirmedWorn &&
      millis() - lastWornPacketMs > HELMET_TIMEOUT_MS) {
    helmetConfirmedWorn = false;
    setRelay(false);
    digitalWrite(STATUS_LED_PIN, LOW);
    Serial.println();
    Serial.println("[WARNING] HELMET RF SIGNAL LOST / TIMEOUT.");
    Serial.println("[RELAY] OFF - demo output de-energized.");
    showStatus("Helmet-worn packets timed out");
  }

  // Stop the alert buzzer after its timed interval.
  if (buzzerOn && millis() - buzzerStartMs >= ACCIDENT_BUZZER_MS) {
    stopBuzzer();
    Serial.println("[BUZZER] OFF.");
  }

  // Print a periodic status report.
  if (millis() - lastStatusMs >= STATUS_INTERVAL_MS) {
    lastStatusMs = millis();
    showStatus("Periodic update");
  }

  delay(2);
}
