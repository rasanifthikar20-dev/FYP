#include <WiFi.h>
#include <Wire.h>
#include <SPI.h>
#include <RF24.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <TinyGPS++.h>

// SMART HELMET: Wi-Fi + ML command + 10-second buzzer + SMS + call.
// IMPORTANT: One SIM800L cannot send SMS and hold a voice call at the same
// time. This code starts the buzzer independently, sends SMS, then calls.

const char* ssid = "RasanM04";
const char* password = "rasan123";
IPAddress serverIP(10, 188, 241, 26); // CHANGE to laptop IPv4
const uint16_t serverPort = 5000;
WiFiClient mlClient;
unsigned long lastWiFiAttempt = 0;
const unsigned long WIFI_RETRY_INTERVAL = 5000;

RF24 radio(4, 5); // CE, CSN
const byte address[6] = "A1001";
const char helmetID[] = "HELMET_001";
const uint8_t RF_CHANNEL = 100; // Must match bike receiver
bool radioReady = false;

Adafruit_MPU6050 mpu;
bool mpuReady = false;

TinyGPSPlus gps;
HardwareSerial GPSSerial(2); // GPS TX -> GPIO16, GPS RX -> GPIO17
String lastLatitude = "";
String lastLongitude = "";
bool hasLastLocation = false;

HardwareSerial sim800(1); // SIM800L TX -> GPIO27, RX -> GPIO26
const char phoneNumber[] = "+94766116637"; // CHANGE to recipient number

const int fsrPin = 34;
const int ledPin = 2;
const int buzzerPin = 13;
const int fsrThreshold = 3500; // Calibrate for your FSR

bool accidentSent = false;
bool emergencyRunning = false;
unsigned long lastSensorSend = 0;
const unsigned long SENSOR_SEND_INTERVAL = 100;

// ---------------- Wi-Fi ----------------
void connectToMLServer() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Connecting to mobile hotspot...");
    WiFi.disconnect();
    WiFi.begin(ssid, password);
    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
      delay(500);
      Serial.print(".");
    }
    Serial.println();
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("ESP32 Wi-Fi IP: ");
    Serial.println(WiFi.localIP());
    if (!mlClient.connected()) {
      mlClient.stop();
      Serial.print("Connecting to Python server...");
      if (mlClient.connect(serverIP, serverPort)) {
        Serial.println(" CONNECTED");
      } else {
        Serial.println(" FAILED");
      }
    }
  } else {
    Serial.println("Hotspot connection failed.");
  }
}

void maintainWiFi() {
  if (WiFi.status() != WL_CONNECTED || !mlClient.connected()) {
    if (millis() - lastWiFiAttempt >= WIFI_RETRY_INTERVAL) {
      lastWiFiAttempt = millis();
      connectToMLServer();
    }
  }
}

// ---------------- GPS ----------------
void updateGPS() {
  while (GPSSerial.available()) gps.encode(GPSSerial.read());

  if (gps.location.isValid() && gps.location.age() < 10000) {
    lastLatitude = String(gps.location.lat(), 6);
    lastLongitude = String(gps.location.lng(), 6);
    hasLastLocation = true;
  }
}

// ---------------- 10-second buzzer task ----------------
void buzzerTask(void* parameter) {
  digitalWrite(buzzerPin, HIGH);
  Serial.println("BUZZER ON for 10 seconds");
  vTaskDelay(pdMS_TO_TICKS(10000));
  digitalWrite(buzzerPin, LOW);
  Serial.println("BUZZER OFF");
  vTaskDelete(NULL);
}

void startBuzzerFor10Seconds() {
  BaseType_t result = xTaskCreate(
    buzzerTask, "Buzzer10s", 2048, NULL, 1, NULL
  );
  if (result != pdPASS) {
    Serial.println("Could not start buzzer task; fallback delay.");
    digitalWrite(buzzerPin, HIGH);
    delay(10000);
    digitalWrite(buzzerPin, LOW);
  }
}

// ---------------- SIM800L helpers ----------------
bool waitForModemChar(char expected, unsigned long timeoutMs) {
  unsigned long start = millis();
  while (millis() - start < timeoutMs) {
    while (sim800.available()) {
      char c = (char)sim800.read();
      Serial.write(c);
      if (c == expected) return true;
    }
    delay(1);
  }
  return false;
}

bool sendSMS(const String& latitude, const String& longitude) {
  Serial.println("\nPreparing emergency SMS...");
  while (sim800.available()) sim800.read();

  sim800.println("AT");
  delay(300);
  while (sim800.available()) Serial.write(sim800.read());

  sim800.println("AT+CMGF=1");
  delay(500);
  while (sim800.available()) Serial.write(sim800.read());

  sim800.print("AT+CMGS=\"");
  sim800.print(phoneNumber);
  sim800.println("\"");

  Serial.println("Waiting for SMS prompt...");
  if (!waitForModemChar('>', 10000)) {
    Serial.println("\nSMS ERROR: prompt not received.");
    return false;
  }

  sim800.print("SMART HELMET EMERGENCY ALERT: Accident detected. ");
  if (latitude != "UNKNOWN" && longitude != "UNKNOWN") {
    sim800.print("GPS: https://maps.google.com/?q=");
    sim800.print(latitude);
    sim800.print(",");
    sim800.print(longitude);
  } else {
    sim800.print("GPS location unavailable.");
  }
  sim800.write(26); // Ctrl+Z submits SMS

  Serial.println("\nSMS submitted; waiting for modem response.");
  unsigned long start = millis();
  String response;
  while (millis() - start < 20000) {
    while (sim800.available()) {
      char c = (char)sim800.read();
      Serial.write(c);
      response += c;
    }
    if (response.indexOf("+CMGS:") >= 0 && response.indexOf("OK") >= 0) {
      Serial.println("\nModem accepted SMS submission.");
      return true;
    }
    if (response.indexOf("ERROR") >= 0) {
      Serial.println("\nSIM800L reported SMS ERROR.");
      return false;
    }
    delay(10);
  }
  Serial.println("\nSMS response timeout; delivery not confirmed.");
  return false;
}

void makeCall() {
  Serial.println("\nMaking emergency call...");
  while (sim800.available()) sim800.read();

  sim800.print("ATD");
  sim800.print(phoneNumber);
  sim800.println(";");

  // Call for up to 10 seconds.
  unsigned long start = millis();
  while (millis() - start < 10000) {
    while (sim800.available()) Serial.write(sim800.read());
    delay(10);
  }

  sim800.println("ATH");
  delay(500);
  while (sim800.available()) Serial.write(sim800.read());
  Serial.println("\nEmergency call ended.");
}

// ---------------- NRF24 alert ----------------
void sendRFAccidentMessage() {
  if (!radioReady) {
    Serial.println("WARNING: NRF24L01 unavailable; RF alert not sent.");
    return;
  }

  char message[32] = {0};
  snprintf(message, sizeof(message), "%s:ACCIDENT", helmetID);
  bool acknowledged = radio.write(message, sizeof(message));
  Serial.println(acknowledged
    ? "RF accident message acknowledged."
    : "RF accident acknowledgement failed.");
}

// ---------------- Emergency sequence ----------------
void emergencyProcess() {
  if (accidentSent || emergencyRunning) return;

  emergencyRunning = true;
  accidentSent = true; // Latch now to avoid duplicate emergency calls
  Serial.println("\n*** ACCIDENT CONFIRMED - STARTING EMERGENCY RESPONSE ***");

  // Runs independently while the modem functions are waiting.
  startBuzzerFor10Seconds();

  sendRFAccidentMessage();

  updateGPS();
  String latitude = "UNKNOWN";
  String longitude = "UNKNOWN";
  if (gps.location.isValid() && gps.location.age() < 10000) {
    latitude = String(gps.location.lat(), 6);
    longitude = String(gps.location.lng(), 6);
    lastLatitude = latitude;
    lastLongitude = longitude;
    hasLastLocation = true;
  } else if (hasLastLocation) {
    latitude = lastLatitude;
    longitude = lastLongitude;
  }

  if (latitude != "UNKNOWN") {
    Serial.print("Latitude: "); Serial.println(latitude);
    Serial.print("Longitude: "); Serial.println(longitude);
  } else {
    Serial.println("GPS fix unavailable.");
  }

  // Same accident event triggers both actions, but a single SIM800L
  // must perform SMS and voice calling one after the other.
  bool smsOk = sendSMS(latitude, longitude);
  Serial.println(smsOk
    ? "SMS submission acknowledged by modem."
    : "SMS submission could not be confirmed.");
  makeCall();

  emergencyRunning = false;
  Serial.println("*** EMERGENCY PROCESS FINISHED ***");
}

// ---------------- Python command over TCP ----------------
void checkPythonCommand() {
  if (!mlClient.connected()) return;
  while (mlClient.available()) {
    String cmd = mlClient.readStringUntil('\n');
    cmd.trim();
    if (cmd.length() == 0) continue;

    Serial.print("Command from Python: ");
    Serial.println(cmd);
    if (cmd == "A" && !accidentSent && !emergencyRunning) {
      emergencyProcess();
      return;
    }
  }
}

// ---------------- Setup ----------------
void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(fsrPin, INPUT);
  digitalWrite(ledPin, LOW);
  digitalWrite(buzzerPin, LOW);

  Wire.begin(21, 22);
  GPSSerial.begin(9600, SERIAL_8N1, 16, 17);
  sim800.begin(9600, SERIAL_8N1, 27, 26);

  Serial.println("\n======================================");
  Serial.println("       SMART HELMET SYSTEM");
  Serial.println("======================================");
  Serial.println("GPS serial initialized.");
  Serial.println("SIM800L serial initialized.");

  SPI.begin(18, 19, 23, 5); // SCK, MISO, MOSI, CSN
  delay(100);
  radioReady = radio.begin();
  if (radioReady) {
    radio.setChannel(RF_CHANNEL);
    radio.setDataRate(RF24_250KBPS);
    radio.setPALevel(RF24_PA_LOW);
    radio.setRetries(5, 15);
    radio.openWritingPipe(address);
    radio.stopListening();
    Serial.println("NRF24L01 initialized.");
  } else {
    Serial.println("NRF24L01 NOT FOUND! Check wiring and 3.3V supply.");
  }

  mpuReady = mpu.begin();
  if (mpuReady) {
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
    Serial.println("MPU6050 initialized.");
  } else {
    Serial.println("ERROR: MPU6050 not detected.");
  }

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  connectToMLServer();
  lastWiFiAttempt = millis();

  Serial.println("\nSystem Ready.");
  Serial.println("Waiting for helmet...");
}

// ---------------- Main loop ----------------
void loop() {
  updateGPS();
  maintainWiFi();

  int fsrValue = analogRead(fsrPin);
  if (fsrValue > fsrThreshold) {
    digitalWrite(ledPin, HIGH);

    if (radioReady) {
      char helmetMsg[32] = {0};
      snprintf(helmetMsg, sizeof(helmetMsg), "%s:HELMET_WORN", helmetID);
      radio.write(helmetMsg, sizeof(helmetMsg));
    }

    if (mpuReady && mlClient.connected() &&
        millis() - lastSensorSend >= SENSOR_SEND_INTERVAL) {
      lastSensorSend = millis();
      sensors_event_t a, g, temp;
      mpu.getEvent(&a, &g, &temp);
      mlClient.printf("%.2f,%.2f,%.2f,%.2f,%.2f,%.2f\n",
        a.acceleration.x, a.acceleration.y, a.acceleration.z,
        g.gyro.x, g.gyro.y, g.gyro.z);
    }

    checkPythonCommand();
    delay(5);
  } else {
    digitalWrite(ledPin, LOW);
    // Allow another event after helmet is removed.
    accidentSent = false;
    emergencyRunning = false;
    delay(50);
  }
}
